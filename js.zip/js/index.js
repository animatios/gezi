window.onload = function () {
    var box = document.querySelector('.box')
    var one = document.querySelector('.one')
    console.log(one);
    var oneee = true
    var two = document.querySelector('.two')
    var twooo = true
    var three = document.querySelector('.three')
    var threeee = true
    var four = document.querySelector('.four')
    var fourrr = true

    var gezi = document.querySelector('.gezi')
    var gz = document.querySelector('.gezitu')

    // 第一段
    var load2 = document.querySelector('.load2')
    var load3 = document.querySelector('.load3')
    var load4 = document.querySelector('.load4')
    var load5 = document.querySelector('.load5')
    var load6 = document.querySelector('.load6')
    var load7 = document.querySelector('.load7')
    var load8 = document.querySelector('.load8')

    // 第二段
    var load24 = document.querySelector('.load24')
    var dianhua = document.querySelector('.load27')
    var load9 = document.querySelector('.load9')
    var load10 = document.querySelector('.load10')
    var load11 = document.querySelector('.load11')
    var load12 = document.querySelector('.load12')
    var load13 = document.querySelector('.load13')
    // 第三段
    var load15 = document.querySelector('.load15')
    var load29 = document.querySelector('.load29')
    var load14 = document.querySelector('.load14')
    var load16 = document.querySelector('.load16')
    var load17 = document.querySelector('.load17')
    var load18 = document.querySelector('.load18')
    var load19 = document.querySelector('.load19')
    // 第四段
    var load31 = document.querySelector('.load31')
    var load30 = document.querySelector('.load30')
    var load20 = document.querySelector('.load20')
    var load21 = document.querySelector('.load21')
    var load22 = document.querySelector('.load22')
    var load23 = document.querySelector('.load23')

    var one1 = false
    var one2 = false
    var one3 = false
    var one4 = false

    var phone = document.querySelector('.phone')
    var wifi = document.querySelector('.wifi')
    var moon = document.querySelector('.moon')

    // 光圈1
    var yuan1 = document.querySelector('.yuan1')
    var yuan2 = document.querySelector('.yuan2')
    var yuan3 = document.querySelector('.yuan3')
    var yuan4 = document.querySelector('.yuan4')

    var s_top = document.querySelector('.s-top')
    var s_center = document.querySelector('.s-center')
    var jiantou = document.querySelector('.jiantou')

    var load32 = document.querySelector('.load32')
    var load25 = document.querySelector('.load25')
    var load26 = document.querySelector('.load26')
    var load28 = document.querySelector('.load28')
    var wenzi = document.querySelector('.wenzi')

    var wz2 = document.querySelector('.wz2')
    var wz3 = document.querySelector('.wz3')
    var wz4 = document.querySelector('.wz4')

    // var abc = document.querySelectorAll('.abc')
    // console.log(abc);

    // 向上滑动
    var startY, endY;
    box.addEventListener('touchstart', function (e) {
        startY = e.touches[0].pageY;
        // console.log(startY);
    })
    box.addEventListener('touchend', tops)
    function tops(e) {
        endY = e.changedTouches[0].pageY
        // console.log(endY);
        uptop = startY - endY
        if (uptop > 0) {
            box.removeEventListener('touchend', tops)

            // 滑动后隐藏
            // s_top.style.display = 'none'
            s_center.style.display = 'none'
            jiantou.style.display = 'none'
            // 滑动后显示
            // 摩天轮
            load32.style.visibility = 'visible'
            // 三个建筑
            load25.style.display = 'block'
            load26.style.display = 'block'
            load28.style.display = 'block'

            load2.style.display = 'block'
            load3.style.display = 'block'
            load4.style.display = 'block'
            load5.style.display = 'block'
            load6.style.display = 'block'
            load7.style.display = 'block'
            load8.style.display = 'block'
            yuan1.style.display = 'block'
            setTimeout(()=>{
                s_top.style.animation = 'stops 1s forwards'
                wz2.style.animation = 'wz2 1s forwards'
            },2700)

        }
    }





    yuan1.onclick = function () {
        yuan1.style.display = 'none'

        // 设置按钮为false
        oneee = false
        gezi.setAttribute('class', 'gezi1')


        // 第一段
        var i = 1
        var a = setInterval(() => {
            if (i > 5) i = 1
            gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
            i++
        }, 100)

        // 第二段
        setTimeout(() => {
            var i = 11
            var num = 0
            clearInterval(a)
            var b = setInterval(() => {

                if (i > 15) i = 11
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 14) clearInterval(b)
            }, 100)
        }, 2000)

        // 第三段
        setTimeout(() => {
            var i = 1
            var num = 0
            var c = setInterval(() => {
                if (i > 5) i = 1
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 31) clearInterval(c)
            }, 100)
        }, 3310)

        // 第四段
        setTimeout(() => {
            var i = 11
            var num = 0
            var d = setInterval(() => {
                if (i > 15) i = 11
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 19) {
                    gz.setAttribute('src', '../suoyougezi/gz11.png')
                    clearInterval(d)
                    
                    // oneee = true
                    one1 = true
                    // 第一个升起的柱子和电话
                    load24.style.display = 'block'
                    dianhua.style.display = 'block'
                    // 改变文字
                    setTimeout(() =>{
                        wz2.style.animation = 'wz2s 1s forwards'
                        wz3.style.animation = 'wz3s 1s forwards'
                    },1000)

                    setTimeout(() => {
                        phone.style.animation = 'xxxx 1s linear infinite'
                        load9.style.display = 'block'
                        load10.style.display = 'block'
                        load11.style.display = 'block'
                        load12.style.display = 'block'
                        load13.style.display = 'block'

                        yuan2.style.display = 'block'


                    }, 1000)

                 

                }

            }, 100)
        }, 6370)

    }


    // 第一次
    one.onclick = function () {
        // 如果不为true
        if (!oneee) {
            // 停止执行
            return
        } else {
            // 如果为false
            if (one1) {
                // 则瞬移
                gezi.setAttribute('class', 'gezi2s')
                // oneee = false
                // 停止执行
                return
            } else {

            }
        }
        // 开关变量，不允许点击
        // if(aaa == true){
        // aaa = false

    }



    yuan2.onclick = function(){
        yuan2.style.display = 'none'

        oneee = false
        twooo = false

        gezi.setAttribute('class', 'gezi2')
        // 第一段
        // setTimeout(() =>{
        var i = 1
        var e = setInterval(() => {
            if (i > 5) i = 1
            gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
            i++

        }, 100)
        // })

        // 第二段
        setTimeout(() => {
            var i = 11
            var num = 0
            clearInterval(e)
            var f = setInterval(() => {
                if (i > 15) i = 11
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 40) {
                    clearInterval(f)
                    gz.setAttribute('src', '../suoyougezi/gz21.png')
                    // aaa = true
                    // one1 = false
                    // oneee = true
                    twooo = true
                    one2 = true

                    load15.style.display = 'block'
                    load29.style.display = 'block'

                    // 改变文字
                    setTimeout(()=>{
                        wz3.style.animation = 'wz3 1s forwards'
                        wz4.style.animation = 'wz4s 1s forwards'
                    },1000)

                    setTimeout(() => {
                        wifi.style.animation = 'vvvv 1s linear infinite'
                        load14.style.display = 'block'
                        load16.style.display = 'block'
                        load17.style.display = 'block'
                        load18.style.display = 'block'
                        load19.style.display = 'block'
                        yuan3.style.display = 'block'

                        
                    }, 1000)
                       setTimeout(()=>{
                        oneee = true

                    },4000)

                }
            }, 100);
        }, 600)
    }



    // 第二次
    two.onclick = function () {
        
        // 如果不为true
        if (!twooo) {
            return
        } else {
            // 如果为false
            if (one2) {
                gezi.setAttribute('class', 'gezi3s')
                // oneee = false
                // twooo = false
                // one2 = false

                return
            } else {

            }
        }
        // if(aaa == true){
        // aaa = false 

        // }
    }


    yuan3.onclick = function(){
        yuan3.style.display = 'none'
        oneee = false
        twooo = false
        threeee = false

        gezi.setAttribute('class', 'gezi3')
        // 第一段
        var i = 21
        var g = setInterval(() => {
            if (i > 25) i = 21
            gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
            i++
        }, 100);

        // 第二段
        setTimeout(() => {
            var i = 31
            var num = 0
            clearInterval(g)
            var h = setInterval(() => {
                if (i > 35) i = 31
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 13) clearInterval(h)
            }, 100);
        }, 1423)

        // 第三段
        setTimeout(() => {
            var i = 21
            var num = 0
            var m = setInterval(() => {
                if (i > 25) i = 21
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 23) {
                    clearInterval(m)
                    gz.setAttribute('src', '../suoyougezi/gz31.png')
                    // aaa = true
                    
                    threeee = true
                    one3 = true
                    

                    load31.style.display = 'block'
                    load30.style.display = 'block'

                    // 改变文字
                    

                    setTimeout(() => {
                        moon.style.animation = 'tttt 1s linear infinite'
                        load20.style.display = 'block'
                        load21.style.display = 'block'
                        load22.style.display = 'block'
                        load23.style.display = 'block'
                        yuan4.style.display = 'block'


                        
                    }, 1000)
                    setTimeout(()=>{
                        twooo = true
                        oneee= true
                    },4000)

                }
            }, 100)
        }, 2742)
    }


    // 第三次
    three.onclick = function () {
        
        // 如果不为true
        if (!threeee) {
            return
        } else {
            // 如果为false
            if (one3) {
                gezi.setAttribute('class', 'gezi4s')
                // twooo = false
                // threeee = false
                // one3 = false

                return
            } else {
         
            }
        }
        // if(aaa == true){
        // aaa = false


        // }
    }


    yuan4.onclick = function(){
        yuan4.style.display = 'none'
        oneee = false
        twooo = false
        threeee = false
        fourrr = false

        gezi.setAttribute('class', 'gezi4')
        // 第一段
        var i = 31
        var n = setInterval(() => {
            if (i > 35) i = 31
            gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
            i++
        }, 100)

        // 第二段
        setTimeout(() => {
            var i = 31
            var num = 0
            clearInterval(n)
            var o = setInterval(() => {
                if (i > 35) i = 31
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 11) clearInterval(o)
            }, 100)
        }, 1159)

        // 第三段
        setTimeout(() => {
            var i = 1
            var num = 0
            var p = setInterval(() => {
                if (i > 5) i = 1
                gz.setAttribute('src', '../suoyougezi/gz' + i + '.png')
                i++
                num++
                if (num == 12) {
                    clearInterval(p)
                    gz.setAttribute('src', '../suoyougezi/gz31.png')
                    // aaa = true
                    oneee = true
                    twooo = true
                    threeee = true
                    fourrr = true
                    one4 = true

                }
            }, 100)
        }, 2167);
    }


    // 第四次
    four.onclick = function () {
        // 不为true
        if (!fourrr) {
            return
        } else {
            // 如果为false
            if (one4) {
                gezi.setAttribute('class', 'gezi5s')
                return
            } else {
          
            }
        }
       
    }


}